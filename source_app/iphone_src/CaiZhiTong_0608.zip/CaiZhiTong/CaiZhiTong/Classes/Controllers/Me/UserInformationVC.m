//
//  UserInformationVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "UserInformationVC.h"

@interface UserInformationVC ()

@property (weak, nonatomic) IBOutlet UILabel *usernameLabel;
@property (weak, nonatomic) IBOutlet UILabel *protectionMoneyLabel;
@property (weak, nonatomic) IBOutlet UILabel *usableProtectionMoneyLabel;
@property (weak, nonatomic) IBOutlet UILabel *buyFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *sellFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *saveFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *saveDayLabel;
@property (weak, nonatomic) IBOutlet UILabel *phoneNumberLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;

@end

@implementation UserInformationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self getUserInfo];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - API functions
#pragma mark -

- (void)getUserInfo {
    [SVProgressHUD show];
    [[APIManager sharedManager] getUserInfoWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"wapindex"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                NSString* username = [UtilManager validString:responseDict[key_user_name]];
                NSNumber* protectionMoney = [UtilManager validNumber:responseDict[key_protection_money]];
                NSNumber* usableProtectionMoney = [UtilManager validNumber:responseDict[key_usable_protection_money]];
                NSNumber* buyFee = [UtilManager validNumber:responseDict[key_buy_fee]];
                NSNumber* sellFee = [UtilManager validNumber:responseDict[key_sell_fee]];
                NSNumber* saveFee = [UtilManager validNumber:responseDict[key_save_fee]];
                NSString* saveDay = [UtilManager validString:responseDict[key_save_day]];
                NSString* phoneNum = [UtilManager validString:responseDict[key_phone_num]];
                NSDictionary* dateInfo = responseDict[key_date];
                NSString* date = [UtilManager validString:dateInfo[key_date]];
                if (date && date.length > 0) {
                    date = [date componentsSeparatedByString:@"."][0];
                }
                
                self.usernameLabel.text = [NSString stringWithFormat:@"姓名 : %@", username];
                self.protectionMoneyLabel.text = [NSString stringWithFormat:@"保证金 : %.2f元", protectionMoney.floatValue];
                self.usableProtectionMoneyLabel.text = [NSString stringWithFormat:@"可用 : %.2f元", usableProtectionMoney.floatValue];
                self.buyFeeLabel.text = [NSString stringWithFormat:@"买入手续费 : %.1f%%", buyFee.floatValue];
                self.sellFeeLabel.text = [NSString stringWithFormat:@"卖出手续费 : %.1f%%", sellFee.floatValue];
                self.saveFeeLabel.text = [NSString stringWithFormat:@"留手续费 : %.1f%%", saveFee.floatValue];
                self.saveDayLabel.text = [NSString stringWithFormat:@"最大留 日期 : %@天", saveDay];
                self.phoneNumberLabel.text = [NSString stringWithFormat:@"手机号 : %@", phoneNum];
                self.dateLabel.text = [NSString stringWithFormat:@"日期 : %@", date];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_error]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:@"Error"
                                                             message:error
                                                            parentVC:self
                                                           okHandler:nil];
                }
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"wapindex error %@", error.localizedDescription);
        [[AlertManager sharedManager] showAlertWithTitle:@"Error"
                                                 message:[error localizedDescription]
                                                parentVC:self
                                               okHandler:nil];
    }];
}


@end
