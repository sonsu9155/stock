//
//  Define.h
//  
//
//  Created by Admin on 4/11/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#ifndef Define_h
#define Define_h

#define AppName                             @"财智通"

#define ScreenBounds                        [UIScreen mainScreen].bounds

#define Documents_Folder                    [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

#define ServerUrl                           [[[NSBundle mainBundle] infoDictionary] valueForKey:@"APIServerURL"]

#define UIColorFromRGB(rgbHex)              [UIColor colorWithRed:((float)((rgbHex & 0xFF0000) >> 16))/255.0 green:((float)((rgbHex & 0xFF00) >> 8))/255.0 blue:((float)(rgbHex & 0xFF))/255.0 alpha:1.0]

// #EBE7E4
#define App_BGColor                         [UIColor colorWithRed:170/255.f green:153/255.f blue:102/255.f alpha:1.f]


//#define WakeelCountPerPage                  10


#define Prefix_Age                          @"Age : "
#define Prefix_Address                      @"Address : "
#define Prefix_NumberAuthorisationDone      @"Number authorisation done : "
#define Prefix_Rating                       @"Rating"


#define key_HTTPAuth                        @"HTTPAuth"

#define key_fail                            @"fail"
#define key_success                         @"success"


#define key_available_money                 @"available_money"
#define key_buy_amount                      @"buy_amount"
#define key_buy_code                        @"buy_code"
#define key_buy_fee                         @"buy_fee"
#define key_buy_history                     @"buy_history"
#define key_buy_num                         @"buy_num"
#define key_buy_price                       @"buy_price"
#define key_buy_type                        @"buy_type"
#define key_buys_price                      @"buys_price"
#define key_cn_name                         @"cn_name"
#define key_code                            @"code"
#define key_content                         @"content"
#define key_contents                        @"contents"
#define key_cost                            @"cost"
#define key_created_at                      @"created_at"
#define key_cur_price                       @"cur_price"
#define key_cy                              @"cy"
#define key_date                            @"date"
#define key_day                             @"day"
#define key_email                           @"email"
#define key_error                           @"error"
#define key_from                            @"from"
#define key_gain                            @"gain"
#define key_id                              @"id"
#define key_image_url                       @"image_url"
#define key_info                            @"info"
#define key_message                         @"message"
#define key_messages                        @"messages"
#define key_method                          @"method"
#define key_name                            @"name"
#define key_news                            @"news"
#define key_num                             @"num"
#define key_password                        @"password"
#define key_phone_num                       @"phone_num"
#define key_protection_money                @"protection_money"
#define key_reason                          @"reason"
#define key_response                        @"response"
#define key_save_day                        @"save_day"
#define key_save_fee                        @"save_fee"
#define key_sell_amount                     @"sell_amount"
#define key_sell_cost                       @"sell_cost"
#define key_sell_fee                        @"sell_fee"
#define key_sell_history                    @"sell_history"
#define key_sh                              @"sh"
#define key_status                          @"status"
#define key_stockcode                       @"stockcode"
#define key_subject                         @"subject"
#define key_sz                              @"sz"
#define key_timezone                        @"timezone"
#define key_timezone_type                   @"timezone_type"
#define key_title                           @"title"
#define key_token                           @"token"
#define key_total_cost                      @"total_cost"
#define key_total_gain                      @"total_gain"
#define key_useable_amount                  @"useable_amount"
#define key_usable_protection_money         @"usable_protection_money"
#define key_user_name                       @"user_name"
#define key_user_status                     @"user_status"
#define key_username                        @"username"



typedef enum TabItem
{
    TabItem_Home = 0,
    TabItem_Transaction = 1,
    TabItem_Information = 2,
    TabItem_Me = 3,
}
TabItem;

typedef enum TransactionType
{
    TransactionType_Buy = 0,
    TransactionType_HoldPosition = 1,
    TransactionType_Details = 2
}
TransactionType;

typedef enum BuyOption
{
    BuyOption_Finance = 1,
    BuyOption_ShortSell = 2
}
BuyOption;


#endif /* Define_h */
