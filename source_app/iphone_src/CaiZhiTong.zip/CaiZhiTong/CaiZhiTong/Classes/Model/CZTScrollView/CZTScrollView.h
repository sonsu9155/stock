//
//  CZTScrollView.h
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CZTScrollView;

enum {
    CZTScrollViewDirectionHorizontal =   0,
    CZTScrollViewDirectionVertical   =   1,
};typedef NSUInteger CZTScrollViewDirection;

enum {
    CZTScrollViewTransitionAuto      =   0,
    CZTScrollViewTransitionForward   =   1,
    CZTScrollViewTransitionBackward  =   2
}; typedef NSUInteger CZTScrollViewTransition;


@protocol CZTScrollViewDelegate <NSObject>
@optional
- (void)lazyScrollViewWillBeginDragging:(CZTScrollView *)pagingView;
//Called when it scrolls, except from as the result of self-driven animation.
- (void)lazyScrollViewDidScroll:(CZTScrollView *)pagingView at:(CGPoint) visibleOffset;
//Called whenever it scrolls: through user manipulation, setup, or self-driven animation.
- (void)lazyScrollViewDidScroll:(CZTScrollView *)pagingView at:(CGPoint) visibleOffset withSelfDrivenAnimation:(BOOL)selfDrivenAnimation;
- (void)lazyScrollViewDidEndDragging:(CZTScrollView *)pagingView;
- (void)lazyScrollViewWillBeginDecelerating:(CZTScrollView *)pagingView;
- (void)lazyScrollViewDidEndDecelerating:(CZTScrollView *)pagingView atPageIndex:(NSInteger)pageIndex;
- (void)lazyScrollView:(CZTScrollView *)pagingView currentPageChanged:(NSInteger)currentPageIndex;
@end

typedef UIImageView*(^CZTScrollViewDataSource)(NSUInteger index);


@interface CZTScrollView : UIScrollView

@property (copy)                CZTScrollViewDataSource      dataSource;
@property (nonatomic, assign)   id<CZTScrollViewDelegate>    controlDelegate;

@property (nonatomic,assign)    NSUInteger                      numberOfPages;
@property (readonly)            NSUInteger                      currentPage;
@property (readonly)            CZTScrollViewDirection       direction;

@property (nonatomic, assign) BOOL autoPlay;
@property (nonatomic, assign) CGFloat autoPlayTime; //default 3 seconds

- (id)initWithFrameAndDirection:(CGRect)frame
                      direction:(CZTScrollViewDirection)direction
                 circularScroll:(BOOL) circularScrolling;

- (void)setEnableCircularScroll:(BOOL)circularScrolling;
- (BOOL)circularScrollEnabled;

- (void) reloadData;

- (void) setPage:(NSInteger) index animated:(BOOL) animated;
- (void) setPage:(NSInteger) newIndex transition:(CZTScrollViewTransition) transition animated:(BOOL) animated;
- (void) moveByPages:(NSInteger) offset animated:(BOOL) animated;

- (UIViewController *) visibleViewController;

@end
