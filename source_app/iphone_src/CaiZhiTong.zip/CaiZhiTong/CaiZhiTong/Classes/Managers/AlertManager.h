//
//  AlertManager.h
//  Elava
//
//  Created by Admin on 4/28/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AlertManager : NSObject

+ (AlertManager* _Nullable)sharedManager;

- (void)showAlertWithTitle:(NSString* __nullable)title
                   message:(NSString* __nullable)message
                  parentVC:(UIViewController* __nullable)parentVC
                 okHandler:(void (^ __nullable)(void))okHandler;

- (void)showConfirmWithTitle:(NSString* __nullable)title
                     message:(NSString* __nullable)message
                    parentVC:(UIViewController* __nullable)parentVC
               cancelHandler:(void (^ __nullable)(void))cancelHandler
                   okHandler:(void (^ __nullable)(void))okHandler;


@end

NS_ASSUME_NONNULL_END
