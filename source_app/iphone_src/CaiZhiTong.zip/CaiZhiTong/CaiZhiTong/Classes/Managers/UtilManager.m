//
//  UtilManager.m
//  Elava
//
//  Created by Admin on 4/18/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "UtilManager.h"

@implementation UtilManager

+ (UtilManager*)sharedManager {
    
    static UtilManager* _sharedManager = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        _sharedManager = [[self alloc] init];
    });
    
    return _sharedManager;
}

+ (BOOL)validateEmail:(NSString*)email {
    
    NSString* emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}";
    NSPredicate* emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:email];
}

+ (NSString*)validString:(NSString*)string {
    
    if (string == nil || [string isKindOfClass:[NSNull class]])
        return @"";
    
    if ([string isKindOfClass:[NSNumber class]]) {
        string = [(NSNumber*)string stringValue];
    }
    
    return string;
}

+ (NSNumber*)validNumber:(NSNumber*)number {
    
    if (number == nil || [number isKindOfClass:[NSNull class]])
        return @(0);
    
    if ([number isKindOfClass:[NSString class]]) {
        number = [NSNumber numberWithInteger:[(NSString*)number integerValue]];
    }
    
    return number;
}

+ (NSString*)dateStringFromDate:(NSDate*)date inFormat:(NSString*)format {
    
    if (!date)
        return @"";
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:format];
    
    NSString* strDate = [dateFormatter stringFromDate:date];
    if (!strDate)
        strDate = @"";
    
    return strDate;
}


+ (unsigned)hexColorFromStringColor:(NSString*)strColor {
    unsigned hexColor = 0;
    [[NSScanner scannerWithString:strColor] scanHexInt:&hexColor];
    
    return hexColor;
}

@end
