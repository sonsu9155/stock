//
//  UtilManager.h
//  Wakkil
//
//  Created by Admin on 4/28/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UtilManager : NSObject

+ (UtilManager*)sharedManager;

+ (BOOL)validateEmail:(NSString*)email;

+ (NSString*)validString:(NSString*)string;

+ (NSNumber*)validNumber:(NSNumber*)number;

+ (NSString*)dateStringFromDate:(NSDate*)date inFormat:(NSString*)format;

+ (unsigned)hexColorFromStringColor:(NSString*)strColor;

@end

NS_ASSUME_NONNULL_END
