//
//  HomeVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "HomeVC.h"
#import "CZTScrollView.h"

@interface HomeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;

@end

@implementation HomeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end


@interface HomeVC () <CZTScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *bannerWrapper;

@property (weak, nonatomic) IBOutlet UILabel *shNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *shLabel;
@property (weak, nonatomic) IBOutlet UILabel *szNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *szLabel;
@property (weak, nonatomic) IBOutlet UILabel *cyNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *cyLabel;

@property (weak, nonatomic) IBOutlet UITableView *homeTableView;

@property (strong, nonatomic) NSMutableArray* newsList;

@property (strong, nonatomic) CZTScrollView *bannerScrollView;
@property (strong, nonatomic) NSMutableArray* bannerArray;


@end

@implementation HomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"财智通";
    
    self.newsList = [NSMutableArray arrayWithCapacity:0];
    
    [self getHomeInfo];
    
    [self initBannerScrollView];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - UI functions
#pragma mark -

- (void)initBannerScrollView {
    // PREPARE PAGES
    NSUInteger numberOfPages = 2;
    self.bannerArray = [NSMutableArray arrayWithCapacity:numberOfPages];
    for (NSUInteger k = 0; k < numberOfPages; ++k) {
        [self.bannerArray addObject:[NSNull null]];
    }
    
    CGRect frame = self.bannerWrapper.frame;
    self.bannerScrollView = [[CZTScrollView alloc] initWithFrame:frame];
    [self.bannerScrollView setEnableCircularScroll:YES];
    [self.bannerScrollView setAutoPlay:YES];
    
    __weak __typeof(&*self)weakSelf = self;
    self.bannerScrollView.dataSource = ^(NSUInteger index) {
        return [weakSelf bannerViewAtIndex:index];
    };
    self.bannerScrollView.numberOfPages = numberOfPages;
    [self.bannerWrapper addSubview:self.bannerScrollView];
}

- (UIImageView *)bannerViewAtIndex:(NSInteger)index {
    if (index > self.bannerArray.count || index < 0) return nil;
    id res = [self.bannerArray objectAtIndex:index];
    if (res == [NSNull null]) {
        UIImageView *bannerView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"banner01"]];
        bannerView.contentMode = UIViewContentModeScaleAspectFit;
        
        [self.bannerArray replaceObjectAtIndex:index withObject:bannerView];
        return bannerView;
    }
    return res;
}

- (IBAction)tapTransactionButton:(UIButton*)sender {
    [self.tabBarController setSelectedIndex:TabItem_Transaction];
}

- (IBAction)tapHoldPositionButton:(UIButton*)sender {
}

- (IBAction)tapInformationButton:(UIButton*)sender {
    [self.tabBarController setSelectedIndex:TabItem_Information];
}

- (IBAction)tapMeButton:(UIButton*)sender {
    [self.tabBarController setSelectedIndex:TabItem_Me];
}


#pragma mark - Table view data source
#pragma mark -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.newsList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HomeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HomeCell" forIndexPath:indexPath];
    
    NSDictionary* info = self.newsList[indexPath.row];
    if (info) {
        cell.nameLabel.text = [UtilManager validString:info[key_contents]];
        
        NSDictionary* dateInfo = info[key_date];
        NSString* date = [UtilManager validString:dateInfo[key_date]];
        if (date && date.length > 0) {
            date = [date componentsSeparatedByString:@"."][0];
        }
        cell.dateLabel.text = date;
    }
    
    return cell;
}


#pragma mark - UIScrollView delegate
#pragma mark -

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if ([scrollView isEqual:self.bannerScrollView]) {
        CGFloat pageWidth = self.bannerScrollView.frame.size.width;
        float fractionalPage = self.bannerScrollView.contentOffset.x / pageWidth;
        NSInteger page = lround(fractionalPage);
//        self.bannerPageControl.currentPage = page;
    }
}


#pragma mark - API functions
#pragma mark -

- (void)getHomeInfo {
    [SVProgressHUD show];
    [[APIManager sharedManager] getHomeInfoWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"wapindex2"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                NSArray* shInfo = responseDict[key_sh];
                if (shInfo && [shInfo isKindOfClass:[NSArray class]] && shInfo.count > 4) {
                    self.shNameLabel.text = [UtilManager validString:shInfo[0]];
                    self.shLabel.text = [NSString stringWithFormat:@"%@\n%@%@%%",
                                         [UtilManager validString:shInfo[1]],
                                         [UtilManager validString:shInfo[2]],
                                         [UtilManager validString:shInfo[3]]];
                }
                
                NSArray* szInfo = responseDict[key_sz];
                if (szInfo && [szInfo isKindOfClass:[NSArray class]] && szInfo.count > 4) {
                    self.szNameLabel.text = [UtilManager validString:szInfo[0]];
                    self.szLabel.text = [NSString stringWithFormat:@"%@\n%@%@%%",
                                         [UtilManager validString:szInfo[1]],
                                         [UtilManager validString:szInfo[2]],
                                         [UtilManager validString:szInfo[3]]];
                }
                
                NSArray* cyInfo = responseDict[key_cy];
                if (cyInfo && [cyInfo isKindOfClass:[NSArray class]] && cyInfo.count > 4) {
                    self.cyNameLabel.text = [UtilManager validString:cyInfo[0]];
                    self.cyLabel.text = [NSString stringWithFormat:@"%@\n%@%@%%",
                                         [UtilManager validString:cyInfo[1]],
                                         [UtilManager validString:cyInfo[2]],
                                         [UtilManager validString:cyInfo[3]]];
                }
                
                
                self.newsList = [NSMutableArray arrayWithCapacity:0];
                
                NSArray* values = responseDict[key_news];
                if (values && [values isKindOfClass:[NSArray class]] && values.count > 0) {
                    self.newsList = [NSMutableArray arrayWithArray:values];
                }
                [self.homeTableView reloadData];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_error]];
                if (error != nil && error.length > 0) {
                    NSLog(@"error = %@", error);
                }
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"wapindex2 error %@", error.localizedDescription);
    }];
}


@end
