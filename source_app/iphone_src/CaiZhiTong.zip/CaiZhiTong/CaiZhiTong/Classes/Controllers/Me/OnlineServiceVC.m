//
//  OnlineServiceVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "OnlineServiceVC.h"


@interface OnlineServiceVC ()

@property (weak, nonatomic) IBOutlet UITextField *subjectField;
@property (weak, nonatomic) IBOutlet UIView *messageWrapper;
@property (weak, nonatomic) IBOutlet UITextView *messageTextView;
@property (weak, nonatomic) IBOutlet UIButton *checkButton;

@end

@implementation OnlineServiceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self getAdminName];
    
    [self initUI];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.view.window endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - Navigation
#pragma mark -

- (void)initUI {
    self.messageWrapper.layer.borderColor = [UIColor lightGrayColor].CGColor;
}

- (IBAction)tapHomeButton:(UIButton*)sender {
    [self.tabBarController setSelectedIndex:TabItem_Home];
}

- (IBAction)tapCheckButton:(UIButton*)sender {
    sender.selected = !sender.selected;
}

- (IBAction)tapSendButton:(UIButton*)sender {
    [self sendMessage];
}


#pragma mark - API functions
#pragma mark -

- (void)getAdminName {
    [SVProgressHUD show];
    [[APIManager sharedManager] getAdminNameWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"message_index"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                NSString* adminName = [UtilManager validString:responseDict[key_user_name]];
                [self.checkButton setTitle:adminName forState:UIControlStateNormal];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_error]];
                NSLog(@"message_index error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"message_index error %@", error.localizedDescription);
    }];
}

- (void)sendMessage {
    NSString* subject = self.subjectField.text;
    if (!subject || [subject stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [self.subjectField becomeFirstResponder];
        return;
    }
    
    NSString* message = self.messageTextView.text;
    if (!message || [message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [self.messageTextView becomeFirstResponder];
        return;
    }
    
    [SVProgressHUD show];
    [[APIManager sharedManager] sendMessageWithSubject:subject message:message success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"message_store"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                NSString* content = [UtilManager validString:responseDict[key_content]];
                [[AlertManager sharedManager] showAlertWithTitle:nil message:content parentVC:self okHandler:^{
                }];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_error]];
                NSLog(@"message_store error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"message_store error %@", error.localizedDescription);
    }];
}


@end
