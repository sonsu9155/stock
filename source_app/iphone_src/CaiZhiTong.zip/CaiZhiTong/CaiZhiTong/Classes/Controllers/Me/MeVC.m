//
//  MeVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "MeVC.h"
#import "TransactionVC.h"

@interface MeVC ()

@property (weak, nonatomic) IBOutlet UIImageView *profileImageView;
@property (weak, nonatomic) IBOutlet UILabel *usernameLabel;
@property (weak, nonatomic) IBOutlet UILabel *useableAmountLabel;

@end

@implementation MeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"财智通";
    
    [self getUsernameAndAmount];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - Table view data source
#pragma mark -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        [self.tabBarController setSelectedIndex:TabItem_Transaction];
        
        UINavigationController* transactionNVC = self.tabBarController.viewControllers[TabItem_Transaction];
        TransactionVC* vc = transactionNVC.topViewController;
        [vc showDetailsWrapper];
    }
}


#pragma mark - API functions
#pragma mark -

- (void)getUsernameAndAmount {
    [SVProgressHUD show];
    [[APIManager sharedManager] getUsernameAndAmountWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"getUsernameAndAmount"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                NSString* username = [UtilManager validString:responseDict[key_user_name]];
                NSNumber* useableAmount = [UtilManager validNumber:responseDict[key_useable_amount]];
                
                self.usernameLabel.text = username;
                self.useableAmountLabel.text = [NSString stringWithFormat:@"可用资金：%.2f元", useableAmount.floatValue];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_error]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:@"Error"
                                                             message:error
                                                            parentVC:self
                                                           okHandler:nil];
                }
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"getUsernameAndAmount error %@", error.localizedDescription);
        [[AlertManager sharedManager] showAlertWithTitle:@"Error"
                                                 message:[error localizedDescription]
                                                parentVC:self
                                               okHandler:nil];
    }];
}

@end
