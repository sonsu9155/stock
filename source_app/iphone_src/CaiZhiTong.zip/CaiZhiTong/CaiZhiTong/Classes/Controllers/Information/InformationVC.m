//
//  InformationVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "InformationVC.h"

@interface InformationCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *importantImageView;

@end

@implementation InformationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end



@interface InformationVC ()

@property (weak, nonatomic) IBOutlet UITableView *informationTableView;

@property (strong, nonatomic) NSArray* infos;

@end

@implementation InformationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"财智通";
    
    self.infos = @[@"融资融券与普通借贷的区别",
                   @"基金公司融资融券业务是怎样产生",
                   @"融资融券合法吗？港券宝优势在哪里",
                   @"融资融券T+0举例",
                   @"券商融资融券与融资融券公司区别",
                   @"融资融券平台知识介绍",
                   @"最放心的融资融券在线交易平台"
                   ];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/




#pragma mark - Table view data source
#pragma mark -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.infos.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    InformationCell *cell = [tableView dequeueReusableCellWithIdentifier:@"InformationCell" forIndexPath:indexPath];
    
    // Configure the cell...
    
    if (self.infos.count > indexPath.row) {
        NSString* name = self.infos[indexPath.row];
        cell.nameLabel.text = name;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


@end
