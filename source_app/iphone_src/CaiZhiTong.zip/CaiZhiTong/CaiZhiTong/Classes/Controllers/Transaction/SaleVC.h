//
//  SaleVC.h
//  CaiZhiTong
//
//  Created by Admin on 6/7/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SaleVC : UIViewController

@property (strong, nonatomic) NSString* sellId;

@end

NS_ASSUME_NONNULL_END
