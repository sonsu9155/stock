//
//  APIManager.m
//  Elava
//
//  Created by Admin on 5/27/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "APIManager.h"

@implementation APIManager

+ (APIManager*)sharedManager {
    
    static APIManager* _sharedManager = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        _sharedManager = [[self alloc] init];
    });
    
    return _sharedManager;
}

- (instancetype)init {
    
    self = [super init];
    if (self) {
        self.httpAuth = [[NSBundle mainBundle] objectForInfoDictionaryKey:key_HTTPAuth];
    }
    
    return self;
}

- (NSString*)jsonStringWithJsonDict:(NSDictionary*)jsonDict {
    NSString* jsonString = @"";
    
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:kNilOptions error:nil];
    if (jsonData)
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    return jsonString;
}

- (AFHTTPSessionManager*)getSessionManager {
    AFHTTPSessionManager *manager = [self getSessionManager:@""];
    
    return manager;
}

- (AFHTTPSessionManager*)getSessionManagerWithToken {
    NSString* token = [self getToken];
    AFHTTPSessionManager *manager = [self getSessionManager:token];
    
    return manager;
}

- (AFHTTPSessionManager*)getSessionManager:(NSString*)token {
    NSString *finalyToken = [[NSString alloc] initWithFormat:@"Bearer %@", token];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    [manager.requestSerializer setAuthorizationHeaderFieldWithUsername:self.httpAuth password:token];
    [manager.requestSerializer setValue:finalyToken forHTTPHeaderField:@"Authorization"];
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:
                                                           @"application/x-www-form-urlencoded",
                                                           @"application/json",
                                                           @"text/plain",
                                                           @"text/html",
                                                           nil]];
    
    return manager;
}

+ (NSDictionary*)parseResponseObject:(id)responseObject apiName:(NSString*)apiName {
    NSDictionary* responseDict = responseObject;
    if (responseObject && [responseObject isKindOfClass:[NSData class]]) {
        NSString* responseString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
#if DEBUG
        //        NSLog(@"%@ response string : %@", apiName, responseString);
#endif
        responseDict = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
    }
    else {
#if DEBUG
        //        NSLog(@"%@ response : %@", apiName, responseObject);
#endif
    }
    
    if (responseDict && [responseDict isKindOfClass:[NSArray class]]) {
        if (((NSArray*)responseDict).count > 0) {
            responseDict = ((NSArray*)responseDict)[0];
        }
    }
    NSLog(@"%@ response dictionary : %@", apiName, responseDict);
    
    return responseDict;
}

- (void)saveToken:(NSString*)token {
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    [defaults setValue:token forKey:key_token];
    
    [defaults synchronize];
}

- (NSString*)getToken {
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    NSString* token = [UtilManager validString:[defaults stringForKey:key_token]];
    return token;
}



#pragma mark -
#pragma mark - // CaiZhiTong Apis
#pragma mark -
#pragma mark -

// 1
- (void)loginWithName:(NSString*)name
             password:(NSString*)password
              success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
              failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"login"];
    NSDictionary* params = @{key_name: name,
                             key_password: password
                             };
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager POST:url parameters:params progress:nil success:success failure:failure];
}

// 2
- (void)getUsernameAndAmountWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                                failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"wapindex"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 3
- (void)getUserInfoWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"wapinfo"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 4
- (void)getNewsWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                   failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"wapxiaoxi"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 5
- (void)getHomeInfoWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"wapindex2"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 6
- (void)getImageUrlWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"imageurl"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 7
- (void)getOrderWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                    failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"waporder"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 8
- (void)buyStockWithStockCode:(NSString*)stockCode
                    stockName:(NSString*)stockName
                        count:(NSString*)count
                        price:(NSString*)price
                         type:(NSNumber*)type
                      success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"buystock"];
    NSDictionary* params = @{key_code: stockCode,
                             key_cn_name: stockName,
                             key_buy_num: count,
                             key_buys_price: price,
                             key_buy_type: type
                             };
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager POST:url parameters:params progress:nil success:success failure:failure];
}

// 9
- (void)getTradeWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                    failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"waptrade"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 10
- (void)getSaleWithSellId:(NSString*)sellId
                  success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                  failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"sale_buy"];
    NSDictionary* params = @{key_id: sellId
                             };
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:params progress:nil success:success failure:failure];
}

// 11
- (void)sellStockWithSellId:(NSString*)sellId
                      price:(NSString*)price
                     amount:(NSString*)amount
                    success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                    failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"sell_act"];
    NSDictionary* params = @{key_id: sellId,
                             key_cur_price: price,
                             key_num: amount
                             };
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager POST:url parameters:params progress:nil success:success failure:failure];
}

// 12
- (void)getDetailsWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                      failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"wapmingxi"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 13
- (void)getStockWithStockCode:(NSString*)stockCode
                      success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                      failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"getstock"];
    NSDictionary* params = @{key_stockcode: stockCode
                             };
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:params progress:nil success:success failure:failure];
}

// 14
- (void)getAdminNameWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                        failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"message_index"];
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager GET:url parameters:nil progress:nil success:success failure:failure];
}

// 15
- (void)sendMessageWithSubject:(NSString*)subject
                       message:(NSString*)message
                       success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure {
    
    NSString* url = [ServerUrl stringByAppendingPathComponent:@"message_store"];
    NSDictionary* params = @{key_subject: subject,
                             key_message: message
                             };
    AFHTTPSessionManager *manager = [self getSessionManagerWithToken];
    [manager POST:url parameters:params progress:nil success:success failure:failure];
}


@end
