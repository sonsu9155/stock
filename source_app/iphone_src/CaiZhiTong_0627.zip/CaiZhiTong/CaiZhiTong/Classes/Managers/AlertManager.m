//
//  AlertManager.m
//  Elava
//
//  Created by Admin on 4/28/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "AlertManager.h"

@implementation AlertManager

+ (AlertManager* _Nullable)sharedManager {
    
    static AlertManager* _sharedManager = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        _sharedManager = [[self alloc] init];
    });
    
    return _sharedManager;
}

- (void)showAlertWithTitle:(NSString* __nullable)title
                   message:(NSString* __nullable)message
                  parentVC:(UIViewController* __nullable)parentVC
                 okHandler:(void (^ __nullable)(void))okHandler {
    
//    NSDictionary *bundleInfo = [[NSBundle mainBundle] infoDictionary];
//    NSString *appName = [bundleInfo objectForKey:(NSString*)kCFBundleNameKey];
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"是" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        if (okHandler)
            okHandler();
    }]];
    
//    alert.view.tintColor = MainTintColor;
    
    [parentVC presentViewController:alert animated:YES completion:^{
    }];
}

- (void)showConfirmWithTitle:(NSString* __nullable)title
                     message:(NSString* __nullable)message
                    parentVC:(UIViewController* __nullable)parentVC
               cancelHandler:(void (^ __nullable)(void))cancelHandler
                   okHandler:(void (^ __nullable)(void))okHandler {
    
//    NSDictionary *bundleInfo = [[NSBundle mainBundle] infoDictionary];
//    NSString *appName = [bundleInfo objectForKey:(NSString*)kCFBundleNameKey];
    
    UIAlertController* confirm = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    [confirm addAction:[UIAlertAction actionWithTitle:@"是" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (okHandler)
            okHandler();
    }]];
    [confirm addAction:[UIAlertAction actionWithTitle:@"不是" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        if (cancelHandler)
            cancelHandler();
    }]];
    
//    confirm.view.tintColor = MainTintColor;
    
    [parentVC presentViewController:confirm animated:YES completion:^{
    }];
}

@end
