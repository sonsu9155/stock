//
//  APIManager.h
//  Elava
//
//  Created by Admin on 5/27/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface APIManager : NSObject

@property (strong, nonatomic) NSString* httpAuth;

+ (APIManager*)sharedManager;

- (instancetype)init;

+ (NSDictionary*)parseResponseObject:(id)responseObject apiName:(NSString*)apiName;

- (void)saveToken:(NSString*)token;


#pragma mark -
#pragma mark - // Wakkil Apis
#pragma mark -
#pragma mark -

// 1
- (void)loginWithName:(NSString*)name
             password:(NSString*)password
              success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
              failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 2
- (void)getUsernameAndAmountWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                                failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 3
- (void)getUserInfoWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 4
- (void)getNewsWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 5
- (void)getHomeInfoWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                   failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 6
- (void)getImageUrlWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 7
- (void)getOrderWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                    failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 8
- (void)buyStockWithStockCode:(NSString*)stockCode
                    stockName:(NSString*)stockName
                        count:(NSString*)count
                        price:(NSString*)price
                         type:(NSNumber*)type
                      success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                      failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 9
- (void)getTradeWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                    failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 10
- (void)getSaleWithSellId:(NSString*)sellId
                  success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                  failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 11
- (void)sellStockWithSellId:(NSString*)sellId
                      price:(NSString*)price
                     amount:(NSString*)amount
                    success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                    failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 12
- (void)getDetailsWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                      failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 13
- (void)getStockWithStockCode:(NSString*)stockCode
                      success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                      failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 14
- (void)getAdminNameWithSuccess:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                        failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

// 15
- (void)sendMessageWithSubject:(NSString*)subject
                       message:(NSString*)message
                       success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                       failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;


@end

NS_ASSUME_NONNULL_END
