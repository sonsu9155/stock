//
//  LoginVC.h
//  CaiZhiTone
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginVC : UIViewController

@end

NS_ASSUME_NONNULL_END
