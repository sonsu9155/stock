//
//  MyNewsVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/5/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "MyNewsVC.h"

@interface NewsHeaderCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UILabel *userLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UILabel *identificationLabel;

@end

@implementation NewsHeaderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.userLabel.layer.borderWidth = 0.5f;
    self.userLabel.layer.borderColor = [UIColor whiteColor].CGColor;
    self.titleLabel.layer.borderWidth = 0.5f;
    self.titleLabel.layer.borderColor = [UIColor whiteColor].CGColor;
    self.contentLabel.layer.borderWidth = 0.5f;
    self.contentLabel.layer.borderColor = [UIColor whiteColor].CGColor;
    self.identificationLabel.layer.borderWidth = 0.5f;
    self.identificationLabel.layer.borderColor = [UIColor whiteColor].CGColor;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end

@interface NewsCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UILabel *userLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UILabel *identificationLabel;

@end

@implementation NewsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.userLabel.layer.borderWidth = 0.5f;
    self.userLabel.layer.borderColor = [UIColor whiteColor].CGColor;
    self.titleLabel.layer.borderWidth = 0.5f;
    self.titleLabel.layer.borderColor = [UIColor whiteColor].CGColor;
    self.contentLabel.layer.borderWidth = 0.5f;
    self.contentLabel.layer.borderColor = [UIColor whiteColor].CGColor;
    self.identificationLabel.layer.borderWidth = 0.5f;
    self.identificationLabel.layer.borderColor = [UIColor whiteColor].CGColor;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end



@interface MyNewsVC ()

@property (strong, nonatomic) NSMutableArray* myNewsList;

@end

@implementation MyNewsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.myNewsList = [NSMutableArray arrayWithCapacity:0];
    
    [self getNews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
}

#pragma mark - Table view data source
#pragma mark -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger rowCount = 1;
    if (self.myNewsList) {
        rowCount = 1 + self.myNewsList.count;
    }
    return rowCount;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat rowHeight = 30.f;
    if (indexPath.row == 0) {
        rowHeight = 36.f;
    }
    return rowHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        NewsHeaderCell* cell = [tableView dequeueReusableCellWithIdentifier:@"NewsHeaderCell" forIndexPath:indexPath];
        return cell;
    }
    else {
        NewsCell* cell = [tableView dequeueReusableCellWithIdentifier:@"NewsCell" forIndexPath:indexPath];
        
        NSInteger index = indexPath.row - 1;
        if (index < self.myNewsList.count) {
            NSDictionary* info = [self.myNewsList objectAtIndex:index];
            if (info) {
                cell.userLabel.text = [UtilManager validString:info[key_from]];
                cell.titleLabel.text = [UtilManager validString:info[key_title]];
                cell.contentLabel.text = [UtilManager validString:info[key_content]];
                cell.identificationLabel.text = [UtilManager validString:info[key_status]];
            }
        }
        
        return cell;
    }
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - API functions
#pragma mark -

- (void)getNews {
    [SVProgressHUD show];
    [[APIManager sharedManager] getNewsWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"wapxiaoxi"];
        if (responseDict && [responseDict isKindOfClass:[NSDictionary class]]) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                self.myNewsList = [NSMutableArray arrayWithCapacity:0];
                
                NSArray* messages = responseDict[key_messages];
                if (messages && [messages isKindOfClass:[NSArray class]] && messages.count > 0) {
                    self.myNewsList = [NSMutableArray arrayWithArray:messages];
                }
                [self.tableView reloadData];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"wapxiaoxi error %@", error.localizedDescription);
        [[AlertManager sharedManager] showAlertWithTitle:nil
                                                 message:[error localizedDescription]
                                                parentVC:self
                                               okHandler:nil];
    }];
}


@end
