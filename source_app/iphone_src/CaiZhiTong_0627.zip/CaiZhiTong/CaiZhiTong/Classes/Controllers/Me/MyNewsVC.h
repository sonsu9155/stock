//
//  MyNewsVC.h
//  CaiZhiTong
//
//  Created by Admin on 6/5/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyNewsVC : UITableViewController

@end

NS_ASSUME_NONNULL_END
