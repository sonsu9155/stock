//
//  TransactionVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "TransactionVC.h"
#import "SaleVC.h"


@interface DetailCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UILabel *idLabel;
@property (weak, nonatomic) IBOutlet UILabel *cnNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *methodLabel;
@property (weak, nonatomic) IBOutlet UILabel *costLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *profitLabel;

@end

@implementation DetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end



@interface HoldCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *typeLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *currentPriceLabel;
@property (weak, nonatomic) IBOutlet UILabel *profitLabel;
@property (weak, nonatomic) IBOutlet UIButton *closeButton;

@end

@implementation HoldCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end



@interface TransactionVC ()

@property (weak, nonatomic) IBOutlet UIView *tabWrapper;
@property (weak, nonatomic) IBOutlet UIButton *buyTabButton;
@property (weak, nonatomic) IBOutlet UIButton *holdTabButton;
@property (weak, nonatomic) IBOutlet UIButton *detailTabButton;

@property (weak, nonatomic) IBOutlet UIView *buyWrapper;
@property (weak, nonatomic) IBOutlet UILabel *buyAvailableCreditLabel;
@property (weak, nonatomic) IBOutlet UITextField *buyStockCodeField;
@property (weak, nonatomic) IBOutlet UILabel *buyStockNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *buyCurrentPriceLabel;
@property (weak, nonatomic) IBOutlet UILabel *buyHandlingFeeLabel;
@property (weak, nonatomic) IBOutlet UITextField *buyCommissionCountField;
@property (weak, nonatomic) IBOutlet UIButton *financeButton;
@property (weak, nonatomic) IBOutlet UIButton *shortSellButton;
@property (weak, nonatomic) IBOutlet UIButton *entrustButton;

@property (weak, nonatomic) IBOutlet UIView *buyStockValueWrapper;
@property (weak, nonatomic) IBOutlet UILabel *buySellCostLabel1;
@property (weak, nonatomic) IBOutlet UILabel *buySellCountLabel1;
@property (weak, nonatomic) IBOutlet UILabel *buySellCostLabel2;
@property (weak, nonatomic) IBOutlet UILabel *buySellCountLabel2;
@property (weak, nonatomic) IBOutlet UILabel *buySellCostLabel3;
@property (weak, nonatomic) IBOutlet UILabel *buySellCountLabel3;
@property (weak, nonatomic) IBOutlet UILabel *buySellCostLabel4;
@property (weak, nonatomic) IBOutlet UILabel *buySellCountLabel4;
@property (weak, nonatomic) IBOutlet UILabel *buySellCostLabel5;
@property (weak, nonatomic) IBOutlet UILabel *buySellCountLabel5;
@property (weak, nonatomic) IBOutlet UILabel *buyCurrentCostLabel;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCostLabel1;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCountLabel1;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCostLabel2;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCountLabel2;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCostLabel3;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCountLabel3;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCostLabel4;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCountLabel4;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCostLabel5;
@property (weak, nonatomic) IBOutlet UILabel *buyBuyCountLabel5;

@property (weak, nonatomic) IBOutlet UIImageView *stockImageView;

@property (weak, nonatomic) IBOutlet UIView *holdPositionWrapper;
@property (weak, nonatomic) IBOutlet UIView *holdInfoWrapper;
@property (weak, nonatomic) IBOutlet UILabel *holdBuyingFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *holdSellingFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *holdStorageHandlingFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *holdTotalAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *holdTotalProfitLabel;
@property (weak, nonatomic) IBOutlet UITableView *holdPositionTableView;

@property (weak, nonatomic) IBOutlet UIView *detailsWrapper;
@property (weak, nonatomic) IBOutlet UIView *infoWrapper;
@property (weak, nonatomic) IBOutlet UILabel *buyingFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *sellingFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *storageHandlingFeeLabel;
@property (weak, nonatomic) IBOutlet UILabel *availableLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalLabel;
@property (weak, nonatomic) IBOutlet UITableView *detailTableView;


@property (strong, nonatomic) NSMutableArray *buyHistories;
@property (strong, nonatomic) NSMutableArray *details;

@property (assign, nonatomic) BOOL shouldShowDetailsWrapper;

@end

@implementation TransactionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"财智通";
    
    self.buyHistories = [NSMutableArray arrayWithCapacity:0];
    self.details = [NSMutableArray arrayWithCapacity:0];
    
    [self initUI];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self getOrder];
    [self getStock];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.view.window endEditing:YES];
}


#pragma mark - Navigation
#pragma mark -

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([segue.identifier isEqualToString:@"ShowSaleVC"]) {
        SaleVC* vc = segue.destinationViewController;
        vc.sellId = sender;
    }
}


#pragma mark - UI Functions
#pragma mark -

- (void)initUI {
    if (self.shouldShowDetailsWrapper) {
        self.shouldShowDetailsWrapper = NO;
        [self tapTabButton:self.detailTabButton];
    }
}

- (IBAction)tapTabButton:(UIButton*)sender {
    [self.view.window endEditing:YES];
    
    if (sender == nil)
        return;
    
    self.buyTabButton.selected = sender.tag == TransactionType_Buy;
    self.holdTabButton.selected = sender.tag == TransactionType_HoldPosition;
    self.detailTabButton.selected = sender.tag == TransactionType_Details;
    
    self.buyWrapper.hidden = sender.tag != TransactionType_Buy;
    self.holdPositionWrapper.hidden = sender.tag != TransactionType_HoldPosition;
    self.detailsWrapper.hidden = sender.tag != TransactionType_Details;
    
    self.buyWrapper.alpha = sender.tag == TransactionType_Buy;
    self.holdPositionWrapper.alpha = sender.tag == TransactionType_HoldPosition;
    self.detailsWrapper.alpha = sender.tag == TransactionType_Details;
    
    if ([sender isEqual:self.buyTabButton]) {
        [self getOrder];
        [self getStock];
    }
    else if ([sender isEqual:self.holdTabButton]) {
        [self getTrade];
    }
    else if ([sender isEqual:self.detailTabButton]) {
        [self getDetails];
    }
}

- (IBAction)tapBuyOptionButton:(UIButton*)sender {
    self.financeButton.selected = [sender isEqual:self.financeButton];
    self.shortSellButton.selected = [sender isEqual:self.shortSellButton];
}

- (IBAction)tapEntrustButton:(UIButton*)sender {
    [self.view.window endEditing:YES];
    
    [self buyStock];
}

- (IBAction)tapCloseButton:(UIButton*)sender {
    NSDictionary* info = self.buyHistories[sender.tag];
    if (info) {
        NSString* sellId = [UtilManager validString:info[key_id]];
        [self performSegueWithIdentifier:@"ShowSaleVC" sender:sellId];
    }
}

- (void)showDetailsWrapper {
    if (self.detailTabButton == nil) {
        self.shouldShowDetailsWrapper = YES;
    }
    
    [self tapTabButton:self.detailTabButton];
}


#pragma mark - UITextField delegate
#pragma mark -

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField && [textField isEqual:self.buyStockCodeField]) {
        [self getStock];
    }
}


#pragma mark - UITableView delegates
#pragma mark -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([tableView isEqual:self.holdPositionTableView]) {
        return self.buyHistories.count;
    }
    else if ([tableView isEqual:self.detailTableView]) {
        return self.details.count;
    }
    return 6;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat cellHeight = 70.f;
    if ([tableView isEqual:self.detailTableView]) {
        cellHeight = 100.f;
    }
    return cellHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([tableView isEqual:self.holdPositionTableView]) {
        HoldCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HoldCell" forIndexPath:indexPath];
        
        NSDictionary* info = self.buyHistories[indexPath.row];
        if (info) {
            cell.amountLabel.text = [UtilManager validString:info[key_cost]];
            cell.currentPriceLabel.text = [UtilManager validString:info[key_cur_price]];
            cell.closeButton.tag = indexPath.row;
            
            NSNumber* profit = [UtilManager validNumber:info[key_gain]];
            cell.profitLabel.text = [NSString stringWithFormat:@"%@", profit];
            cell.profitLabel.textColor = profit.floatValue < 0 ? [UIColor greenColor] : [UIColor redColor];
            
            NSInteger method = [UtilManager validNumber:info[key_method]].integerValue;
            if (method == 1) {
                cell.typeLabel.text = @"融资";
                cell.typeLabel.textColor = [UIColor redColor];
            }
            else {
                cell.typeLabel.text = @"融券";
                cell.typeLabel.textColor = [UIColor greenColor];
            }
        }
        
        return cell;
    }
    else if ([tableView isEqual:self.detailTableView]) {
        DetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailCell" forIndexPath:indexPath];
        
        NSDictionary* info = self.details[indexPath.row];
        if (info) {
            cell.idLabel.text = [UtilManager validString:info[key_id]];
            cell.cnNameLabel.text = [UtilManager validString:info[key_cn_name]];
            
            NSDictionary* dateInfo = info[key_created_at];
            NSString* date = [UtilManager validString:dateInfo[key_date]];
            if (date && date.length > 0) {
                date = [date componentsSeparatedByString:@"."][0];
            }
            cell.dateLabel.text = [NSString stringWithFormat:@"时间: %@", date];
            
            NSInteger method = [UtilManager validNumber:info[key_method]].integerValue;
            if (method == 1) {
                cell.methodLabel.text = @"类型";
                cell.methodLabel.textColor = [UIColor greenColor];
            }
            else {
                cell.methodLabel.text = @"买升";
                cell.methodLabel.textColor = [UIColor redColor];
            }
            
            cell.costLabel.text = [NSString stringWithFormat:@"成交价: %@", [UtilManager validString:info[key_sell_cost]]];
            cell.amountLabel.text = [UtilManager validString:info[key_sell_amount]];
            cell.profitLabel.text = [UtilManager validString:info[key_gain]];
        }
        
        return cell;
    }
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark - API functions
#pragma mark -

- (void)getOrder {
    NSString* stockCode = self.buyStockCodeField.text;
    if (!stockCode || stockCode.length < 1) {
        return;
    }
    
    [SVProgressHUD show];
    [[APIManager sharedManager] getOrderWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"waporder"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                self.buyAvailableCreditLabel.text = [NSString stringWithFormat:@"可用额度: %@", [UtilManager validString:responseDict[key_available_money]]];
                self.buyHandlingFeeLabel.text = [NSString stringWithFormat:@"手续费: %@%%", [UtilManager validString:responseDict[key_buy_fee]]];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
                NSLog(@"waporder error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"waporder error %@", error.localizedDescription);
    }];
}

- (void)getStock {
    NSString* stockCode = self.buyStockCodeField.text;
    if (!stockCode || [stockCode stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [[AlertManager sharedManager] showAlertWithTitle:nil message:@"股票代码不应为空。" parentVC:self okHandler:^{
            [self.buyStockCodeField becomeFirstResponder];
        }];
        return;
    }
    
    [SVProgressHUD show];
    [[APIManager sharedManager] getStockWithStockCode:stockCode success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"getstock"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                self.buyStockNameLabel.text = [UtilManager validString:responseDict[@"0"]];
                self.buyCurrentPriceLabel.text = [NSString stringWithFormat:@"现价: %@", [UtilManager validString:responseDict[@"3"]]];
                
                self.buySellCostLabel5.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"29"]]];
                self.buySellCountLabel5.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"28"]]];
                self.buySellCostLabel4.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"27"]]];
                self.buySellCountLabel4.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"26"]]];
                self.buySellCostLabel3.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"25"]]];
                self.buySellCountLabel3.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"24"]]];
                self.buySellCostLabel2.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"23"]]];
                self.buySellCountLabel2.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"22"]]];
                self.buySellCostLabel1.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"21"]]];
                self.buySellCountLabel1.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"20"]]];
                
                self.buyCurrentCostLabel.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"3"]]];
                
                self.buyBuyCostLabel5.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"19"]]];
                self.buyBuyCountLabel5.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"18"]]];
                self.buyBuyCostLabel4.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"17"]]];
                self.buyBuyCountLabel4.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"16"]]];
                self.buyBuyCostLabel3.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"15"]]];
                self.buyBuyCountLabel3.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"14"]]];
                self.buyBuyCostLabel2.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"13"]]];
                self.buyBuyCountLabel2.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"12"]]];
                self.buyBuyCostLabel1.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"11"]]];
                self.buyBuyCountLabel1.text = [NSString stringWithFormat:@"%@", [UtilManager validString:responseDict[@"10"]]];
                
                NSString* imageUrl = [UtilManager validString:responseDict[key_image_url]];
                if (imageUrl && imageUrl.length > 0) {
                    imageUrl = [imageUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                    
                    [self.stockImageView setImageWithURLRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:imageUrl]] placeholderImage:nil success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
                        self.stockImageView.image = image;
                    } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
                        NSLog(@"error : %@", error.localizedDescription);
                    }];
                }
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
                NSLog(@"getstock error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"getstock error %@", error.localizedDescription);
    }];
}

- (void)buyStock {
    NSString* stockCode = self.buyStockCodeField.text;
    if (!stockCode || [stockCode stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [self.buyStockCodeField becomeFirstResponder];
        return;
    }
    
    NSString* stockName = self.buyStockNameLabel.text;
    if (!stockName || [stockName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        return;
    }
    
    NSString* count = self.buyCommissionCountField.text;
    if (!count || [count stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [self.buyCommissionCountField becomeFirstResponder];
        return;
    }
    
    NSString* price = self.buyCurrentCostLabel.text;
    if (!price || [price stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        return;
    }
    
    NSNumber* type = self.financeButton.selected ? @(BuyOption_Finance) : @(BuyOption_ShortSell);
    
    
    [SVProgressHUD show];
    [[APIManager sharedManager] buyStockWithStockCode:stockCode stockName:stockName count:count price:price type:type success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"buystock"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                NSString* content = [UtilManager validString:responseDict[key_content]];
                [[AlertManager sharedManager] showAlertWithTitle:nil message:content parentVC:self okHandler:^{
                }];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
                NSLog(@"buystock error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"buystock error %@", error.localizedDescription);
    }];
}

- (void)getTrade {
    [SVProgressHUD show];
    [[APIManager sharedManager] getTradeWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"waptrade"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                self.holdBuyingFeeLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_buy_fee]]];
                self.holdSellingFeeLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_sell_fee]]];
                self.holdStorageHandlingFeeLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_save_fee]]];
                self.holdTotalAmountLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_total_cost]]];
                self.holdTotalProfitLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_total_gain]]];
                
                self.buyHistories = [NSMutableArray arrayWithCapacity:0];
                
                NSArray* values = responseDict[key_buy_history];
                if (values && [values isKindOfClass:[NSArray class]] && values.count > 0) {
                    self.buyHistories = [NSMutableArray arrayWithArray:values];
                }
                [self.holdPositionTableView reloadData];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
                NSLog(@"waptrade error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"waptrade error %@", error.localizedDescription);
    }];
}

- (void)getDetails {
    [SVProgressHUD show];
    [[APIManager sharedManager] getDetailsWithSuccess:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"wapmingxi"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                self.buyingFeeLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_buy_fee]]];
                self.sellingFeeLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_sell_fee]]];
                self.storageHandlingFeeLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_save_fee]]];
                self.availableLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_available_money]]];
                self.totalLabel.text = [NSString stringWithFormat:@"%@%%", [UtilManager validString:responseDict[key_total_gain]]];
                
                
                self.details = [NSMutableArray arrayWithCapacity:0];
                
                NSArray* values = responseDict[key_sell_history];
                if (values && [values isKindOfClass:[NSArray class]] && values.count > 0) {
                    self.details = [NSMutableArray arrayWithArray:values];
                }
                [self.detailTableView reloadData];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
                NSLog(@"wapmingxi error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"wapmingxi error %@", error.localizedDescription);
    }];
}


@end
