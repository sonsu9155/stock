//
//  SaleVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/7/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "SaleVC.h"

@interface SaleVC ()

@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UILabel *stockNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *stockCodeLabel;
@property (weak, nonatomic) IBOutlet UILabel *holdDateLabel;
@property (weak, nonatomic) IBOutlet UILabel *holdAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *buyPriceLabel;
@property (weak, nonatomic) IBOutlet UILabel *stateLabel;
@property (weak, nonatomic) IBOutlet UILabel *currentPriceLabel;
@property (weak, nonatomic) IBOutlet UIButton *sellPriceButton;
@property (weak, nonatomic) IBOutlet UITextField *sellAmountField;
@property (weak, nonatomic) IBOutlet UIButton *sellAllButton;
@property (weak, nonatomic) IBOutlet UIButton *sellButton;
@property (weak, nonatomic) IBOutlet UITextField *priceField;

@end

@implementation SaleVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self getSale];
    
    [self initUI];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.view.window endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - UI functions
#pragma mark -

- (void)initUI {
    self.wrapper.layer.borderColor = [UIColor lightGrayColor].CGColor;
}

- (IBAction)tapSellPriceButton:(UIButton*)sender {
    sender.selected = !sender.selected;
    
    if (sender.selected) {
        self.priceField.text = self.currentPriceLabel.text;
    }
}

- (IBAction)tapSellAllButton:(UIButton*)sender {
    self.sellAmountField.text = self.holdAmountLabel.text;
}

- (IBAction)tapSellButton:(UIButton*)sender {
    [self sellStocks];
}


#pragma mark - API functions
#pragma mark -

- (void)getSale {
    if (!self.sellId || self.sellId.length < 1) {
        return;
    }
    
    [SVProgressHUD show];
    [[APIManager sharedManager] getSaleWithSellId:self.sellId success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"sale_buy"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                self.stockNameLabel.text = [UtilManager validString:responseDict[key_cn_name]];
                self.stockCodeLabel.text = [UtilManager validString:responseDict[key_buy_code]];
                
                NSDictionary* dateInfo = responseDict[key_created_at];
                NSString* date = [UtilManager validString:dateInfo[key_date]];
                if (date && date.length > 0) {
                    date = [date componentsSeparatedByString:@"."][0];
                }
                self.holdDateLabel.text = date;
                
                self.holdAmountLabel.text = [UtilManager validString:responseDict[key_buy_amount]];
                self.buyPriceLabel.text = [UtilManager validString:responseDict[key_buy_price]];
                self.currentPriceLabel.text = [UtilManager validString:responseDict[key_cur_price]];
                
                if (self.buyPriceLabel.text.floatValue <= self.currentPriceLabel.text.floatValue) {
                    self.stateLabel.textColor = [UIColor redColor];
                    self.stateLabel.text = @"买升↑";
                    self.currentPriceLabel.textColor = [UIColor redColor];
                }
                else {
                    self.stateLabel.textColor = [UIColor greenColor];
                    self.stateLabel.text = @"买降↓";
                    self.currentPriceLabel.textColor = [UIColor greenColor];
                }
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
                NSLog(@"sale_buy error %@", error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"sale_buy error %@", error.localizedDescription);
    }];
}

- (void)sellStocks {
    NSString* price = self.priceField.text;
    if (!price || [price stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [self.priceField becomeFirstResponder];
        return;
    }
    
    NSString* amount = self.sellAmountField.text;
    if (!amount || [amount stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [self.sellAmountField becomeFirstResponder];
        return;
    }
    
    if (amount.integerValue > self.holdAmountLabel.text.integerValue) {
        [self.sellAmountField becomeFirstResponder];
        return;
    }
    
    [SVProgressHUD show];
    [[APIManager sharedManager] sellStockWithSellId:self.sellId price:price amount:amount success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"sell_act"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            NSString* content = [UtilManager validString:responseDict[key_content]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                [[AlertManager sharedManager] showAlertWithTitle:nil message:content parentVC:self okHandler:^{
                }];
            }
            else {
                NSLog(@"sell_act error %@", content);
                [[AlertManager sharedManager] showAlertWithTitle:nil message:content parentVC:self okHandler:^{
                }];
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"sell_act error %@", error.localizedDescription);
    }];
}


@end
