//
//  LoginVC.m
//  CaiZhiTone
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "LoginVC.h"

@interface LoginVC ()

@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;

@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.usernameField.text = @"test1";
    self.passwordField.text = @"123456";
}


#pragma mark - Navigation
#pragma mark -

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([segue.identifier isEqualToString:@"ShowMainVC"]) {
        UITabBarController* tabVC = segue.destinationViewController;
        [tabVC setSelectedIndex:3];
    }
}


#pragma mark - UI Function
#pragma mark -

- (IBAction)tapRememberButton:(UIButton*)sender {
    sender.selected = !sender.selected;
}

- (IBAction)tapLoginButton:(UIButton*)sender {
    // test code
//    [self performSegueWithIdentifier:@"ShowMainVC" sender:nil];
//    return;
    // test
    
    
    NSString* name = self.usernameField.text;
    if (!name || [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [[AlertManager sharedManager] showAlertWithTitle:nil message:@"名称不应为空。" parentVC:self okHandler:^{
            [self.usernameField becomeFirstResponder];
        }];
        return;
    }
    
    NSString* password = self.passwordField.text;
    if (!password || [password stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length < 1) {
        [[AlertManager sharedManager] showAlertWithTitle:nil message:@"密码不应为空。" parentVC:self okHandler:^{
            [self.passwordField becomeFirstResponder];
        }];
        return;
    }
    
    [self loginWithName:name password:password];
}

- (IBAction)tapForgotPasswordButton:(UIButton*)sender {
    
}


#pragma mark - API functions
#pragma mark -

- (void)loginWithName:(NSString*)name password:(NSString*)password {
    
    [SVProgressHUD show];
    
    [[APIManager sharedManager] loginWithName:name password:password success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"login"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status isEqualToString:key_success];
            if (success) {
                NSString* token = [UtilManager validString:responseDict[key_token]];
                [[APIManager sharedManager] saveToken:token];
                
                [[AlertManager sharedManager] showAlertWithTitle:nil message:@"登录成功！" parentVC:self okHandler:^{
                    [self performSegueWithIdentifier:@"ShowMainVC" sender:nil];
                }];
            }
            else {
                NSString* content = [UtilManager validString:responseDict[key_content]];
                NSLog(@"login error: %@", content);
                
                [[AlertManager sharedManager] showAlertWithTitle:nil
                                                         message:content
                                                        parentVC:self
                                                       okHandler:nil];
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"login error %@", error.localizedDescription);
        [[AlertManager sharedManager] showAlertWithTitle:nil
                                                 message:[error localizedDescription]
                                                parentVC:self
                                               okHandler:nil];
    }];
}


@end
