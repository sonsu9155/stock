//
//  ApiTestVC.m
//  CaiZhiTong
//
//  Created by Admin on 6/3/19.
//  Copyright © 2019 Admin. All rights reserved.
//

#import "ApiTestVC.h"

@interface ApiTestVC ()

@end

@implementation ApiTestVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initUI];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    [self updateWrappers];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - ui functions
#pragma mark -

- (void)initUI {
    [self loginWithName:@"" password:@""];
    [self loginWithName:@"test1" password:@"123456"];
}

- (void)updateWrappers {
    
}


#pragma mark - API functions
#pragma mark -

- (void)loginWithName:(NSString*)name password:(NSString*)password {
    
    [SVProgressHUD show];
    
    [[APIManager sharedManager] loginWithName:name password:password success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [SVProgressHUD dismiss];
        
        NSDictionary* responseDict = [APIManager parseResponseObject:responseObject apiName:@"login"];
        if (responseDict) {
            NSString* status = [UtilManager validString:responseDict[key_status]];
            BOOL success = [status.uppercaseString isEqualToString:key_success];
            if (success) {
                NSString* content = responseDict[key_content];
                [[AlertManager sharedManager] showAlertWithTitle:nil message:content parentVC:self okHandler:^{
                    
                }];
            }
            else {
                NSString* error = [UtilManager validString:responseDict[key_content]];
                if (error != nil && error.length > 0) {
                    [[AlertManager sharedManager] showAlertWithTitle:nil message:error parentVC:self okHandler:^{
                    }];
                }
            }
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        NSLog(@"login error %@", error.localizedDescription);
        [[AlertManager sharedManager] showAlertWithTitle:nil
                                                 message:[error localizedDescription]
                                                parentVC:self
                                               okHandler:nil];
    }];
}


@end
